LD_LIBRARY_PATH=./game/lib ./game/fmq-cppgame &
